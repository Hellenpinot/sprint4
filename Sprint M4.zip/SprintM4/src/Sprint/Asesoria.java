package Sprint;

public interface Asesoria {
	
	public void analizarUsuario();
	
}
